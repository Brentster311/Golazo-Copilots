﻿# Changelog

## [1.0.0] - 2026-01-22

### Added
- Initial stable release
- Version metadata (GCP-006)
- Update detection (GCP-007)
