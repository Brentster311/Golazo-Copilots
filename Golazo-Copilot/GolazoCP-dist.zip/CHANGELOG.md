﻿# Changelog

## [1.0.11] - 2026-01-22

### Added
- Update detection and upgrade capability (GCP-007)
- Automatic version checking on session start (24-hour interval)
- Backup-before-upgrade workflow
- Manual update check via "check for Golazo updates"

## [1.0.0] - 2026-01-22

### Added
- Initial stable release
- Version metadata (GCP-006)
- Update detection (GCP-007)
